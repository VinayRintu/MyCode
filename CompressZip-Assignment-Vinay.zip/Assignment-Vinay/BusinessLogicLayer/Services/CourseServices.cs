﻿using BusinessLogicLayer.Repositories;
using Data_Access_Layer.Models;
using DataAccessLayer.DbConnectionFolder;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLogicLayer.Services
{
    public class CourseServices : ICourseRepository
    {
        private readonly DbContextClass? _dbContextClass;
        public CourseServices(DbContextClass? dbConnectionClass)
        {
            _dbContextClass = dbConnectionClass;
        }
        public async Task Add(Course course)
        {
            var entity = new Course
            {
                CourseName = course.CourseName,
                StudentID = course.StudentID
            };
            _dbContextClass.Add(entity);
            await _dbContextClass.SaveChangesAsync();
        }

        public async Task<Course> Get(int id)
        {
            var record=await _dbContextClass.Courses1.FindAsync(id);
            return record;
        }

        public async Task<IEnumerable<Course>> GetAll()
        {
            return await _dbContextClass.Courses1.Include(x=>x.Student).ToListAsync();
        }

        public async Task Update(Course dbentity, Course entity)
        {
           dbentity.CourseName= entity.CourseName;
            dbentity.StudentID= entity.StudentID;
            await _dbContextClass.SaveChangesAsync();
        }
    }
}
