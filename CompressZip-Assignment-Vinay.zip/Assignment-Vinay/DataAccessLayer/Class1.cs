﻿namespace DataAccessLayer
{
    public class Class1
    {

    }
}