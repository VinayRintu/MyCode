﻿using BusinessLogicLayer.Repositories;
using Data_Access_Layer.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;


namespace Assignment_Vinay.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class CourseController : ControllerBase
    {
        private readonly ICourseRepository _courseRepository;
        public CourseController(ICourseRepository courseRepository)
        {
            _courseRepository = courseRepository;
        }
       
        [HttpGet]
        [AllowAnonymous]
        public async Task<IEnumerable<Course>> GetAll()
        {
            return await _courseRepository.GetAll();
        }
        
        [HttpGet("{id}")]
        public async Task<IActionResult> GetByID(int id)
        {
            var record = await _courseRepository.Get(id);
            if (record == null)
            {
                return NotFound("Record Not Found Enter Correct ID");
            }
            //return Ok(record);
            return Ok(record);
        }
        
        [HttpPost]
        public async Task<IActionResult> Insert([FromBody] Course value)
        {
            await _courseRepository.Add(value);
            return Ok("Record Inserted Successfully...");
        }
       
        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, [FromBody] Course value)
        {
            var record = await _courseRepository.Get(id);
            if (record == null)
            {
                return NotFound("Record No Found Please Enter Valid Record ID");
            }
            await _courseRepository.Update(record, value);
            return Ok(value);
        }
    }
}
