﻿using BusinessLogicLayer.Repositories;
using Data_Access_Layer.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Assignment_Vinay.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class StudentController : ControllerBase
    {
        private readonly IStudentRepository _studentRepository;
        private readonly ILogger<StudentController> _logger;

        public StudentController(IStudentRepository studentRepository, ILogger<StudentController> logger) 
        {
            _studentRepository = studentRepository;
            _logger = logger;
        }

        // GET: api/<StudentController>
        [HttpGet]
        [AllowAnonymous]
        public async Task<IEnumerable<Student>> GetAll()
        {
            //var iteracion = 1;
            //_logger.LogDebug($"Debug{iteracion}");
            //_logger.LogInformation($"Information {iteracion}");
            //_logger.LogWarning($"Warning {iteracion}");
            //_logger.LogError($"Error {iteracion}");
            //_logger.LogCritical($"Critical {iteracion}");
            _logger.LogDebug("Error From GetAll method from Student Controller");
            return await _studentRepository.GetAll();
        }

        // GET api/<StudentController>/5
        [HttpGet("{id}")]
        public async Task<IActionResult> GetByID(int id)
        {
           var record=await _studentRepository.Get(id);
            if (record == null)
            {
                return NotFound("Record Not Found Enter Correct ID");
            }
            return Ok(record);
        }

        // POST api/<StudentController>
        [HttpPost]
        public async Task<IActionResult> Insert([FromBody] Student value)
        {
            await _studentRepository.Add(value);
            return Ok("Record Inserted Successfully...");
        }

        // PUT api/<StudentController>/5
        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, [FromBody] Student value)
        {
            var record=await _studentRepository.Get(id);
            if (record == null)
            {
                //return NotFound("Record No Found Please Enter Valid Record ID");
                return NotFound("Record No Found Please Enter Valid Record ID");
            }
           await _studentRepository.Update(record, value);
            return Ok(value);
        }

        // DELETE api/<StudentController>/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            var record=await _studentRepository.Get(id);
            if (record == null)
            {
                return NotFound("Record Not Found Please Enter Valid Record ID");
            }
           await _studentRepository.Delete(record);
            return Ok("Record Deleted Sucessfully");
        }
    }
}
